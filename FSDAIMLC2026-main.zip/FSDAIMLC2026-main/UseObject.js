const div = document.getElementById('container');
const button = document.getElementById('btn');
console.log(div);
const h2 = document.createElement("h2");
h2.innerText = "Data is loading...";
console.log(h2);

async function display(){
    try{
    div.appendChild(h2);
        // div.innerHTML='<h2 style="color:blue;">Hello Using DOM</h2>';
    const serverdata =await fetch('https://fakestoreapi.com/products');
    const jsondata = await serverdata.json();
    // console.log(jsondata[1].title)
    div.innerHTML=`<h2 style="color:white;background-color:grey;"> ${JSON.stringify(jsondata)}</h2>`;

}catch(e){
    console.log("error is:" + e);
}
finally{
div.removeChild(h2);
}
}

button.addEventListener('click',display);
